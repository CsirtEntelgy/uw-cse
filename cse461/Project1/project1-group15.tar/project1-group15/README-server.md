# README - Server

## Source Code

The majority of the source code for the server is in [./server/Server.java](./server/Server.java). This class contains the code that is executed in each thread. The class that spawns new threads is in [./server/ServerRunner.java](./server/ServerRunner.java). Both files depend on classes located in [./utils](./utils).

## Group Members

Josh Cho, NetID: joshua97
Elena Spasova, NetID: elenaspa
Hemil Gajjar, NetID: hemil

## Compiling

The following code block should be run in the root of the unzipped tarball.

```bash
javac $(find ./util/* | grep .java)       # compiling utility classes
javac $(find ./server/* | grep .java)     # compiling server classes
```

## Running

The following code block should be run in the root of the unzipped tarball.

```bash
java ./server/ServerRunner
```
