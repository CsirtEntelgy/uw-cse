package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Objects;

public class VerifiedPacket implements Packet {
    Header header;
    byte[] headerBytes;
    byte[] payloadBytes;

    public VerifiedPacket(Header header, byte[] headerBytes, byte[] payloadBytes) {
        this.header = header;
        this.headerBytes = headerBytes;
        this.payloadBytes = payloadBytes;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public byte[] getHeaderBytes() {
        return headerBytes;
    }

    public void setHeaderBytes(byte[] headerBytes) {
        this.headerBytes = headerBytes;
    }

    public byte[] getPayloadBytes() {
        return payloadBytes;
    }

    public void setPayloadBytes(byte[] payloadBytes) {
        this.payloadBytes = payloadBytes;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 13 * hash + Objects.hashCode(this.header);
        hash = 13 * hash + Arrays.hashCode(this.headerBytes);
        hash = 13 * hash + Arrays.hashCode(this.payloadBytes);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final VerifiedPacket other = (VerifiedPacket) obj;
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        if (!Arrays.equals(this.headerBytes, other.headerBytes)) {
            return false;
        }
        if (!Arrays.equals(this.payloadBytes, other.payloadBytes)) {
            return false;
        }
        return true;
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(headerBytes.length + payloadBytes.length)
                .order(ByteOrder.BIG_ENDIAN)
                .put(headerBytes)
                .put(payloadBytes)
                .array();
    }
}