package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class B1Ack implements Packet {
    public static final int SIZE_BYTES = 4;  // excluding Header

    private Header header;
    private int packetId;

    public B1Ack(Header header, int packetId){
        this.header = header;
        this.packetId = packetId;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public int getPacketId() {
        return packetId;
    }

    public void setPacketId(int packetId) {
        this.packetId = packetId;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.header);
        hash = 29 * hash + this.packetId;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final B1Ack other = (B1Ack) obj;
        if (this.packetId != other.packetId) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }
    
    public static B1Ack fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes, SIZE_BYTES);
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out id field
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        int packetId = buffer.getInt();

        return new B1Ack(verified.getHeader(), packetId);
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(Header.SIZE_BYTES + SIZE_BYTES)
                         .order(ByteOrder.BIG_ENDIAN)
                         .put(header.toBytes())
                         .putInt(packetId)
                         .array();
    }
}
