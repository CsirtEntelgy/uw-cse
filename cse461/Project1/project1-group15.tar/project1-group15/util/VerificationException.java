package util;

public class VerificationException extends RuntimeException {
    public VerificationException(String message) {
        super(message);
    }
}