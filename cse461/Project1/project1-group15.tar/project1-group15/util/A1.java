package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class A1 implements Packet {

    private Header header;
    private String content;

    public A1(String content) {
        // check for \0 terminator
        if (content.charAt(content.length() - 1) != '\0') {
            throw new IllegalArgumentException("No terminator for argument: " + content);
        }

        // UTF-8 encoding => one byte per common character
        this.content = content;
        byte[] contentBytes = content.getBytes(Protocol.CHARSET);
        header = Header.forClient(contentBytes.length, 0);
    }

    private A1(Header header, String content) {
        this.header = header;
        this.content = content;
    }
    
    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.header);
        hash = 67 * hash + Objects.hashCode(this.content);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final A1 other = (A1) obj;
        if (!Objects.equals(this.content, other.content)) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }
    

    public static A1 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes);  // using this overload since size is variable
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out content String
        String content = new String(payloadBytes, Protocol.CHARSET);

        return new A1(verified.getHeader(), content);
    }

    @Override
    public byte[] toBytes() {
        byte[] temp = content.getBytes(Protocol.CHARSET);
        return ByteBuffer.allocate(Header.SIZE_BYTES + temp.length)
                .order(ByteOrder.BIG_ENDIAN)
                .put(header.toBytes())
                .put(temp)
                .array();
    }
}
