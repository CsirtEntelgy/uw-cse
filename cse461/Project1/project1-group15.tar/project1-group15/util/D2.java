package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class D2 implements Packet {
    public static final int SIZE_BYTES = 4;  // excluding Header

    private Header header;
    private int secretD;

    public D2(Header header, int secretD) {
        this.header = header;
        this.secretD = secretD;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public int getSecretD() {
        return secretD;
    }

    public void setSecretD(int secretD) {
        this.secretD = secretD;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.header);
        hash = 17 * hash + this.secretD;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final D2 other = (D2) obj;
        if (this.secretD != other.secretD) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }
    
    public static D2 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes, SIZE_BYTES);
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out payload fields
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        int secretD = buffer.getInt();

        return new D2(verified.getHeader(), secretD);
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(Header.SIZE_BYTES + SIZE_BYTES)
                .order(ByteOrder.BIG_ENDIAN)
                .put(header.toBytes())
                .putInt(secretD)
                .array();
    }
}
