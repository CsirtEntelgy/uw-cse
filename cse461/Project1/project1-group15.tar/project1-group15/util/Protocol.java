package util;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public final class Protocol {
    public static final int UDP_PORT = 12235; //should be 12235 for submission
    public static final int STUDENT_ID = 497;
    public static final String ATTU_HOSTNAME = "localhost"; //attu 2 or 3
    public static final Charset CHARSET = StandardCharsets.ISO_8859_1;
}
