package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class C2 implements Packet {
    public static final int SIZE_BYTES = 13;  // excluding Header
    public static final int ALT_SIZE_BYTES = 16;

    private Header header;
    private int num2, len2, secretC;
    private byte ch;     // avoids ambiguity with two byte chars in Java

    public C2(Header header, int num2, int len2, int secretC, byte ch){
        this.header = header;
        this.num2 = num2;
        this.len2 = len2;
        this.secretC = secretC;
        this.ch = ch;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    public int getLen2() {
        return len2;
    }

    public void setLen2(int len2) {
        this.len2 = len2;
    }

    public int getSecretC() {
        return secretC;
    }

    public void setSecretC(int secretC) {
        this.secretC = secretC;
    }

    public byte getCh() {
        return ch;
    }

    public void setCh(byte ch) {
        this.ch = ch;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.header);
        hash = 53 * hash + this.num2;
        hash = 53 * hash + this.len2;
        hash = 53 * hash + this.secretC;
        hash = 53 * hash + this.ch;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final C2 other = (C2) obj;
        if (this.num2 != other.num2) {
            return false;
        }
        if (this.len2 != other.len2) {
            return false;
        }
        if (this.secretC != other.secretC) {
            return false;
        }
        if (this.ch != other.ch) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }
    
    public static C2 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified;

        // handles possible alternate size of 16 bytes
        try {
            verified = Packet.verify(bytes, SIZE_BYTES);
        } catch (VerificationException e) {
            verified = Packet.verify(bytes, ALT_SIZE_BYTES);
        }
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out payload fields
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        int num2 = buffer.getInt();
        int len2 = buffer.getInt();
        int secretC = buffer.getInt();
        byte ch = buffer.get();

        return new C2(verified.getHeader(), num2, len2, secretC, ch);
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(Header.SIZE_BYTES + SIZE_BYTES)
                .order(ByteOrder.BIG_ENDIAN)
                .put(header.toBytes())
                .putInt(num2)
                .putInt(len2)
                .putInt(secretC)
                .put(ch)
                .array();
    }
}
