package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class A2 implements Packet {
    public static final int SIZE_BYTES = 16;  // excluding Header

    private Header header;
    private int num, len, udpPort, secretA;
    
    public A2(Header header, int num, int len, int udpPort, int secretA){
        this.header = header;
        this.num = num;
        this.len = len;
        this.udpPort = udpPort;
        this.secretA = secretA;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public int getUdpPort() {
        return udpPort;
    }

    public void setUdpPort(int udpPort) {
        this.udpPort = udpPort;
    }

    public int getSecretA() {
        return secretA;
    }

    public void setSecretA(int secretA) {
        this.secretA = secretA;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.header);
        hash = 97 * hash + this.num;
        hash = 97 * hash + this.len;
        hash = 97 * hash + this.udpPort;
        hash = 97 * hash + this.secretA;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final A2 other = (A2) obj;
        if (this.num != other.num) {
            return false;
        }
        if (this.len != other.len) {
            return false;
        }
        if (this.udpPort != other.udpPort) {
            return false;
        }
        if (this.secretA != other.secretA) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }

    public static A2 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes, SIZE_BYTES);
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out payload fields
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        int num = buffer.getInt();
        int len = buffer.getInt();
        int udpPort = buffer.getInt();
        int secretA = buffer.getInt();

        return new A2(verified.getHeader(), num, len, udpPort, secretA);
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(Header.SIZE_BYTES + SIZE_BYTES)
                         .order(ByteOrder.BIG_ENDIAN)
                         .put(header.toBytes())
                         .putInt(num)
                         .putInt(len)
                         .putInt(udpPort)
                         .putInt(secretA)
                         .array();
    }
}
