package util;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class B1 implements Packet {

    private Header header;
    private int packetId;
    private int payloadLen;
    
    public B1(Header header, int packetId, int payloadLen){
        this.header = header;
        this.packetId = packetId;
        this.payloadLen = payloadLen;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public int getPacketId() {
        return packetId;
    }

    public void setPacketId(int packetId) {
        this.packetId = packetId;
    }

    public int getPayloadLen() {
        return payloadLen;
    }

    public void setPayloadLen(int payloadLen) {
        this.payloadLen = payloadLen;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.header);
        hash = 29 * hash + this.packetId;
        hash = 29 * hash + this.payloadLen;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final B1 other = (B1) obj;
        if (this.packetId != other.packetId) {
            return false;
        }
        if (this.payloadLen != other.payloadLen) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }

    public static B1 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes);  // using this overload since size is variable
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out payload fields
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        int packetId = buffer.getInt();
        int payloadLen = 0;

        // increment payloadLen while next byte is 0
        while (true) {
            try {
                if (buffer.get() == 0) {
                    payloadLen++;
                } else {
                    throw new VerificationException("payload contains nonzero byte");
                }
            } catch (BufferUnderflowException e) {
                break;
            }
        }

        return new B1(verified.getHeader(), packetId, payloadLen);
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(Header.SIZE_BYTES + 4 + payloadLen)
                         .order(ByteOrder.BIG_ENDIAN)
                         .put(header.toBytes())
                         .putInt(packetId)
                         // payload is already zeroed out
                         .array();
    }
}
