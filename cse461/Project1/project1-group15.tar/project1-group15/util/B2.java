package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

public class B2 implements Packet {
    public static final int SIZE_BYTES = 8;  // excluding Header

    private Header header;
    private int tcpPortNum;
    private int secretB;

    public B2(Header header, int tcpPortNum, int secretB){
        this.header = header;
        this.tcpPortNum = tcpPortNum;
        this.secretB = secretB;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public int getTcpPortNum() {
        return tcpPortNum;
    }

    public void setTcpPortNum(int tcpPortNum) {
        this.tcpPortNum = tcpPortNum;
    }

    public int getSecretB() {
        return secretB;
    }

    public void setSecretB(int secretB) {
        this.secretB = secretB;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.header);
        hash = 17 * hash + this.tcpPortNum;
        hash = 17 * hash + this.secretB;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final B2 other = (B2) obj;
        if (this.tcpPortNum != other.tcpPortNum) {
            return false;
        }
        if (this.secretB != other.secretB) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }
    
    public static B2 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes, SIZE_BYTES);
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out payload fields
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        int tcpPortNum = buffer.getInt();
        int secretB = buffer.getInt();

        return new B2(verified.getHeader(), tcpPortNum, secretB);
    }

    @Override
    public byte[] toBytes() {
        return ByteBuffer.allocate(Header.SIZE_BYTES + SIZE_BYTES)
                         .order(ByteOrder.BIG_ENDIAN)
                         .put(header.toBytes())
                         .putInt(tcpPortNum)
                         .putInt(secretB)
                         .array();
    }
}
