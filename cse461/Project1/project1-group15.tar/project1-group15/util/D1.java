package util;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Objects;

public class D1 implements Packet {

    private Header header;
    private byte ch;
    private int len2;

    public D1(Header header, byte ch, int len2){
        this.header = header;
        this.ch = ch;
        this.len2 = len2;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public byte getCh() {
        return ch;
    }

    public void setCh(byte ch) {
        this.ch = ch;
    }

    public int getLen2() {
        return len2;
    }

    public void setLen2(int len2) {
        this.len2 = len2;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + Objects.hashCode(this.header);
        hash = 13 * hash + this.ch;
        hash = 13 * hash + this.len2;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final D1 other = (D1) obj;
        if (this.ch != other.ch) {
            return false;
        }
        if (this.len2 != other.len2) {
            return false;
        }
        if (!Objects.equals(this.header, other.header)) {
            return false;
        }
        return true;
    }
    
    public static D1 fromBytes(byte[] bytes) throws VerificationException {
        VerifiedPacket verified = Packet.verify(bytes);  // using this overload since size is variable
        byte[] payloadBytes = verified.getPayloadBytes();

        // pull out payload fields
        ByteBuffer buffer = ByteBuffer.wrap(payloadBytes);
        byte ch = buffer.get();
        int len2 = 1;

        // increment payloadLen while next byte is c
        while (true) {
            try {
                if (buffer.get() == ch) {
                    len2++;
                } else {
                    throw new VerificationException("payload contains non-c byte");
                }
            } catch (BufferUnderflowException e) {
                break;
            }
        }

        return new D1(verified.getHeader(), ch, len2);
    }

    @Override
    public byte[] toBytes() {
        byte[] arr = new byte[len2];
        Arrays.fill(arr, ch);

        return ByteBuffer.allocate(Header.SIZE_BYTES + len2)
                .order(ByteOrder.BIG_ENDIAN)
                .put(header.toBytes())
                .put(arr)
                .array();
    }
}
