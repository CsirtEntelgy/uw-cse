package util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Header {
    public static final int SIZE_BYTES = 12;
    private int payloadLen, psecret;    // signed, 32-bit
    private char step, studentID;       // unsigned, 16-bit

    public Header(int payloadLen, int psecret, char step, char studentID) {
        this.payloadLen = payloadLen;
        this.psecret = psecret;
        this.step = step;
        this.studentID = studentID;
    }

    public int getPayloadLen() {
        return payloadLen;
    }

    public void setPayloadLen(int payloadLen) {
        this.payloadLen = payloadLen;
    }

    public int getPsecret() {
        return psecret;
    }

    public void setPsecret(int psecret) {
        this.psecret = psecret;
    }

    public char getStep() {
        return step;
    }

    public void setStep(char step) {
        this.step = step;
    }

    public char getStudentID() {
        return studentID;
    }

    public void setStudentID(char studentID) {
        this.studentID = studentID;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.payloadLen;
        hash = 71 * hash + this.psecret;
        hash = 71 * hash + this.step;
        hash = 71 * hash + this.studentID;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Header other = (Header) obj;
        if (this.payloadLen != other.payloadLen) {
            return false;
        }
        if (this.psecret != other.psecret) {
            return false;
        }
        if (this.step != other.step) {
            return false;
        }
        if (this.studentID != other.studentID) {
            return false;
        }
        return true;
    }
    
    public static Header fromBytes(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes, 0, SIZE_BYTES);
        int payloadLen = buffer.getInt();
        int psecret = buffer.getInt();
        char step = buffer.getChar();
        char studentID = buffer.getChar();

        return new Header(payloadLen, psecret, step, studentID);
    }

    public static Header forClient(int payloadLen, int psecret) {
        return new Header(payloadLen, psecret, (char) 1, (char) Protocol.STUDENT_ID);
    }

    public static Header forServer(int payloadLen, int psecret) {
        return new Header(payloadLen, psecret, (char) 2, (char) Protocol.STUDENT_ID);
    }

    public byte[] toBytes() {
        return ByteBuffer.allocate(SIZE_BYTES)
                         .order(ByteOrder.BIG_ENDIAN)
                         .putInt(payloadLen)
                         .putInt(psecret)
                         .putChar(step)
                         .putChar(studentID)
                         .array();
    }
}
