package client;

import java.io.*;
import java.net.*;
import java.util.Optional;

import util.*;

public class Client {

    private static final DatagramSocket udpSocket;
    private Socket tcpSocket; // created global for step C and D

    
    static {
        try {
            udpSocket = new DatagramSocket();   // any available socket on localhost
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public static void main(String[] args) {
        System.out.println("--- Start Client ---\n");

        Client client = new Client();
        while (true) {
            boolean complete = client.stageA()
                                     .flatMap(client::stageB)
                                     .flatMap(client::stageC)
                                     .flatMap(client::stageD)
                                     .isPresent();
            if (complete) {
                break;
            }
        }
        
        System.out.println("--- End Client, Success! ---");
    }

    private Optional<A2> stageA() {
        System.out.println("* Start StageA *");
        
        // encapsulates fromBytes and toBytes for this message
        A1 message = new A1("hello world\0");

        SocketAddress destinationA = new InetSocketAddress(Protocol.ATTU_HOSTNAME, Protocol.UDP_PORT);
        System.out.println("Using UDP Port : " + Protocol.UDP_PORT);
        
        Utils.sendBytesUDP(message.toBytes(), udpSocket, destinationA);

        try {
            // wait for response
            byte[] responseBytes = new byte[Header.SIZE_BYTES + A2.SIZE_BYTES];
            DatagramPacket receivedPacket = new DatagramPacket(responseBytes, responseBytes.length);
            udpSocket.receive(receivedPacket);

            // parse response into A2 object
            A2 response = A2.fromBytes(receivedPacket.getData());
            
            System.out.println("StageA Secret : " + response.getSecretA());
            System.out.println("* End stageA *\n");
            
            return Optional.of(response);
        } catch (IOException | VerificationException e) {
            // DatagramSocket::receive() throws IOException
            // A2::fromBytes() throws IndexOutOfBoundsException
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private Optional<B2> stageB(A2 prev) {
        System.out.println("* Start StageB *");
        
        SocketAddress destinationB = new InetSocketAddress(Protocol.ATTU_HOSTNAME, prev.getUdpPort());
        System.out.println("Using UDP Port : " + prev.getUdpPort());
        
        // establish 500 ms timeout for resending
        try {
            udpSocket.setSoTimeout(500);
        } catch (SocketException e) {
            return Optional.empty();
        }

        int counter = 0;
        Header header = Header.forClient(prev.getLen() + 4, prev.getSecretA());

        while (counter < prev.getNum()) {
            // creating B1 packet to send
            B1 packet = new B1(header, counter, prev.getLen());
            byte[] packetData = packet.toBytes();

            // resend loop for current B1 packet
            while (true) {
                try {
                    // sending and receiving...
                    Utils.sendBytesUDP(packetData, udpSocket, destinationB);
                    byte[] response = Utils.receiveBytesUDP(udpSocket, Header.SIZE_BYTES + B1Ack.SIZE_BYTES);
                    B1Ack responsePacket = B1Ack.fromBytes(response);

                    // only move to next packet if response matches
                    if (counter == responsePacket.getPacketId()) {
                        counter++;
                        break;
                    }
                } catch (VerificationException | IOException e) {
                    System.out.println("Response Timed out, Resending...");
                }
            }
        }

        try {
            udpSocket.setSoTimeout(0);  // remove timeout, set to infinite

            // receive and return B2
            byte[] responseBytes = Utils.receiveBytesUDP(udpSocket, Header.SIZE_BYTES + B2.SIZE_BYTES);
            B2 response = B2.fromBytes(responseBytes);
            
            System.out.println("StageB Secret : " + response.getSecretB());
            System.out.println("* End stageB *\n");
            
            return Optional.of(response);
        } catch (IOException | VerificationException e) {
            // UDP IO error or unverifiable message -> fail stage
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private Optional<C2> stageC(B2 prev) {
        System.out.println("* Start StageC *");
        
        SocketAddress destinationC = new InetSocketAddress(Protocol.ATTU_HOSTNAME, prev.getTcpPortNum());
        System.out.println("Using TCP Port : " + prev.getTcpPortNum());

        // Making TCP Connection via server socket
        try {
            tcpSocket = new Socket();
            tcpSocket.connect(destinationC);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Read from server & convert to byte array - !!!need to discuss the size boundary (char being 1 byte)
        byte[] data = new byte[25]; // 12 for header 13 for payload (??)
        try {
            tcpSocket.getInputStream().read(data);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create C2 object and return
        C2 response = C2.fromBytes(data);
        
        System.out.println("StageC Secret : " + response.getSecretC());
        System.out.println("* End stageC *\n");
        
        return Optional.of(response);
    }

    private Optional<D2> stageD(C2 prev) {
        System.out.println("* Start StageD *");
        
        int counter = 0;
        Header header = Header.forClient(prev.getLen2(), prev.getSecretC());
        System.out.println("Using TCP Port : " + tcpSocket.getPort());

        // Send Num2 number of packets via TCP
        while(counter < prev.getNum2()){
            D1 packet = new D1(header, prev.getCh(), prev.getLen2());
            try {
                tcpSocket.getOutputStream().write(packet.toBytes());
                tcpSocket.getOutputStream().flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            counter++;
        }

        // Read from server
        byte[] data = new byte[16]; //12 for header, 4 for payload
        try{
            tcpSocket.getInputStream().read(data);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create D2 object and return
        D2 response = D2.fromBytes(data);
        
        System.out.println("StageD Secret : " + response.getSecretD());
        System.out.println("* End stageD *\n");
        
        return Optional.of(response);
    }
}
