# README - Client

## Source Code

The majority of the source code for the client is in [./client/Client.java](./client/Client.java), but this code depends on classes located in [./utils](./utils/).

## Group Members

Josh Cho, NetID: joshua97
Elena Spasova, NetID: elenaspa
Hemil Gajjar, NetID: hemil

## Sample Secrets Received:

Secret A: 98
Secret B: 74
Secret C: 41
Secret D: 8

## Compiling

The following code block should be run in the root of the unzipped tarball.

```bash
javac $(find ./util/* | grep .java)       # compiling utility classes
javac $(find ./client/* | grep .java)     # compiling client classes
```

## Running

The following code block should be run in the root of the unzipped tarball.

```bash
java ./client/Client
```
